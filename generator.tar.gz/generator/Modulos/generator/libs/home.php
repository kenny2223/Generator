<?php

include "/var/www/html/modules/generator/template/Yealink.php"; 


$file=shell_exec('find /tftpboot -type f -name \'*.'.$suffix.'\' | wc -l');



$server=$_SERVER['SERVER_ADDR'];



$pNet = new paloNetwork();
$arrNetwork = $pNet->obtener_configuracion_red();

if(is_array($arrNetwork))  $arrNetworkData['host'] = isset($arrNetwork['host'])?$arrNetwork['host']:'';

$servername=$arrNetworkData['host'];


?>

<input type="hidden" id="S_file" value="<?php echo $suffix ?>">
<input id="Server" type="hidden" value="<?php echo $server?>">
<input type="hidden" id="Servername" value="<?php echo $servername ?>">

<div class="alert alert-success collapse" style="position: absolute;z-index: 100;" role="alert"></div>


<div class="container">

<div class="col-sm-4 col-lg-4">
  <div class="panel panel-default">
    <div class="panel-heading">Servidor Xinetd</div>
    <div class="panel-body">
    <?php 
    $state=statedeamon();
    $e = ($state == "active") ? 'disabled' : '';
      echo "<label style=\"display:block;\" >Estado: ".getstate()."</label>";
     
      echo "<button type=\"button\" class=\"btn btn-success\" id=\"xinetd\" $e >Activar</button>";
      ?>
    </div>
  </div>
  </div>


  <div class="col-sm-3 col-lg-3">
  <div class="panel panel-default">
    <div class="panel-heading">Cantidad de archivos en /tftpboot</div>
    <div class="panel-body">
    <?php 

    $l = ($file > 0) ? '' : 'disabled';

      echo "<label style=\"display:block;\" id=\"suffix\">$file $suffix</label>";
      echo "<button type=\"button\" class=\"btn btn-success\" id=\"D_file\" $l> Eliminar </button>";
      ?>
    </div>
  </div>
  </div>
</div>
 
<hr>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <textarea class="form-control" id="General" rows="50" ><?php echo $General ?></textarea>
</div>
<div class="row">
<button style="cursor:pointer;position: absolute; right:0px;" onclick="openNav()">Configuracion General&#9881;</button>
</div>


<div class="row">
<div class="input-group  col-sm-2 col-lg-2">
<span class="input-group-addon" style="color: black;">Fabricante</span>
<select id="Brand" class="form-control">
    <option>Yealink</option>
    <option>Grandstream</option>
  </select> 
  </div>
  <div  class=" col-sm-2 col-lg-2" style="margin-left: 5px;" >
  <span  style="color: black;">Prefijo Mac</span>
  <input type="text" maxlength="6" style="width: 80px;"  id="P_Mac" value="">
  </div>
    
</div>

<hr>
<ul class="nav nav-tabs" role="tablist">
  <li class="active"><a href="#account" role="tab" data-toggle="tab">Cuenta</a></li>
  <li><a href="#red" role="tab" data-toggle="tab">Red</a></li>
  <li><a href="#Seguridad" role="tab" data-toggle="tab">Seguridad</a></li>
  <li><a href="#ldap" role="tab" data-toggle="tab">Ldap</a></li>
  
</ul>
</li>


<!-- Tab panes -->
<div class="tab-content">
  <div class="tab-pane active" id="account">
    <br>
<div class="row">

<div class="input-group col-sm-2 col-lg-2">
<span class="input-group-addon" style="color: black;">admin</span>
<span style="position: absolute;right:0 " data-toggle="tooltip" data-placement="right" title="Password de Web"  class="glyphicon glyphicon-info-sign "></span>
<input type="text" class="form-control"  style="width: 110px;" id="P_admin" placeholder="Password for Web" value="Sen31994">
</div>

<div class="input-group col-sm-2 col-lg-2">
<span class="input-group-addon" style="color: black;">Idiomas</span>
<select type="text" class="form-control"   id="lang" placeholder="Password for Web" value="Sen31994">
<option value="es" selected>Español</option>
  <option value="en" >Ingles</option>
  <option value="po">Portugues</option>
</select>
</div>

</div>
<br>
<div class="row">
<div class="btn-group" id="BtnGroup" style="color: black; margin-left:20px;">
<button class="btn btn-default active" value='ip'>IP</button>
<button class="btn btn-default" value='host'>Hostname</button>
<span  data-toggle="tooltip" data-placement="bottom" title="Obtene la ip o el hostname del servidor para el registro de la cuenta"  class="glyphicon glyphicon-info-sign "></span>
<label style="color: black; margin-left:20px;"  id="showtoggle"><?php echo $server?></label>
  </div>
  </div>
  </div>
  
  <div class="tab-pane" id="red">
  <div class="row">
<div  class="col-sm-2 col-lg-2">
<span  style="color: black;">Prefijo Ip</span>
<input type="text"   id="P_ip" value="">
</div>

<div  class="col-sm-2 col-lg-2">
<span  style="color: black;">Mascara</span>
<input type="text"   id="mask" value="">
</div>

<div  class="col-sm-2 col-lg-2">
<span  style="color: black;">Gateway</span>
<input type="text"   id="gateway" value="">
</div>
<span  data-toggle="tooltip" data-placement="bottom" title="Valido solo cuando se desactiva DHCP para usar Ip estatica en los telefonos"  class="glyphicon glyphicon-info-sign "></span>
</div>

<br>
<div  class=row>
  <div  class="col-sm-2 col-lg-2">
<span  style="color: black;">DNS Primario</span>
<input type="text"   style="width: 100px;" id="dns1" value="">
</div>
<div  class="col-sm-2 col-lg-2">
<span  style="color: black;">DNS Secundario</span>
<input type="text"   style="width: 100px;" id="dns2" value="">
</div>
  
  </div>
<br>
<div  class=row>
  <div  class="col-sm-2 col-lg-2">
<span  style="color: black;">Vlan Id</span>
<input type="number"  style="width: 100px;" id="vlan" min="1" max="4096" value="">
</div>
  
  </div>
  </div>

 

  <div class="tab-pane" id="Seguridad">

<div class="row">

<div class="input-group col-sm-2 col-lg-2">
<span class="input-group-addon" style="color: black;">HTTPS</span>
<span style="position: absolute;right:0 " data-toggle="tooltip" data-placement="bottom" title="Se habilita el https,cambiar el puerto(opcional)"  class="glyphicon glyphicon-info-sign "></span>
<input type="number" class="form-control"  style="width: 110px;" id="https" min="1" max="4096" value="443">
</div>
</div>
<br>
<div class="row">
  <div class="checkbox" style="color: black; margin-left:20px;">
  <label><input type="checkbox" value=""  id="pwd" checked>Password Reset</label>
  <span  data-toggle="tooltip" data-placement="bottom" title="Por seguridad se Habilita el Password para reseteo de fabrica"  class="glyphicon glyphicon-info-sign "></span>
</div>

</div>


</div>

<div class="tab-pane" id="ldap">

<div class="row">
  <div class="checkbox" style="color: black; margin-left:20px;">
  <label><input type="checkbox" value=""  id="ldapenable" >Habilitar</label>
  <span  data-toggle="tooltip" data-placement="bottom" title="Se remomienda tener issabel-ldap instalado. sino hacer la conexion a otro servidor"  class="glyphicon glyphicon-info-sign "></span>
</div>
</div>


<br>

<div class="row">
<form class="form-horizontal" style="color: black; margin-left:20px;">

    <div class="form-group">
    <label class="control-label col-md-1" for="ldapserver">Servidor:</label>
      <div class="col-md-2">
        <input type="text" class="form-control" id="ldapserver" placeholder="" value="<?php echo $server?>">
      </div>

      <label class="control-label col-md-1" for="ldapport">Puerto:</label>
      <div class="col-md-1">
        <input type="text" class="form-control" id="ldapport" placeholder="" name="email" value="10389">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-1" for="ldapbase">Base:</label>
      <div class="col-md-1">
        <input type="text" class="form-control" id="ldapbase" placeholder="" value="dc=asterisk">
      </div>
      <label class="control-label col-md-1" for="ldapuser">Username:</label>
      <div class="col-md-3">
        <input type="text" class="form-control" id="ldapuser" placeholder="" value="cn=admin,dc=pbx,dc=com">
      </div>
      <label class="control-label col-md-1" for="ldappwd">Password:</label>
      <div class="col-md-1">
        <input type="text" class="form-control input-sm" id="ldappwd" placeholder="" value="">
      </div>
    </div>

    
    <div class="form-group">
      <label class="control-label col-md-2" for="ldapFN">Filtro Nombre:</label>
      <div class="col-md-2">
        <input type="text" class="form-control" id="ldapFN" placeholder="" value="(|(cn=%)(sn=%))">
      </div>
      <label class="control-label col-md-2" for="ldapFNum">Filtro Numero:</label>
      <div class="col-md-3">
        <input type="text" class="form-control" id="ldapFNum" placeholder="" value="(|(telephoneNumber=%)(homePhone=%))">
      </div>
    
    </div>

    <div class="form-group">
      <label class="control-label col-md-1" for="ldapdis">Display:</label>
      <div class="col-md-1">
        <input type="text" class="form-control" id="ldapdis" placeholder="" value="%cn">
      </div>
      <label class="control-label col-md-2" for="ldapattn">Atributo Nombre:</label>
      <div class="col-md-1">
        <input type="text" class="form-control" id="ldapattn" placeholder="" value="cn">
      </div>
      <label class="control-label col-md-2" for="ldapattnum">Atributo Numero:</label>
      <div class="col-md-2">
        <input type="text" class="form-control input-sm" id="ldapattnum" placeholder="" value="telephoneNumber homePhone">
      </div>
    </div>


  

  </form>

</div>

  
</div>


<br>
<hr>
<div class="fluid-container">
 <br><br>
<table id="my"  style='width:100%' >
   <thead>
   <?php
   
        $head=array("Name","Extension","Password","Mac Address","Conexion","IP");
        foreach ($head as  $value) {
            echo "<th>$value</th>";
        }
       
   ?>
</thead> 

<tbody >

<?php
foreach (getexts() as $k=> $v) {
      echo "<tr >";
      echo "<td ><label >{$v['Name']}</label></td>";
      echo "<td><label >{$v['Number']}</label></td>";
      echo "<td><label >{$v['Password']}</label></td>";
      echo "<td><input type=\"text\" style=\"width: 120px;\" class=\"Mac\" maxlength=\"12\" placeholder=\"\"></td>";
      echo "<td><label><input type=\"checkbox\"  id=\"checkbox\" checked>DHCP</label></td>";
     
      echo "<td><input style=\"width: 120px;\" type=\"text\" placeholder=\"\" disabled  class=\"ip\" maxlength=\"15\"></td>";
      
      echo "</tr>";
      }

      

   ?>

</tbody>
</table>
<button type="submit" id="csv" value="submitted">
<img src="modules/generator/images/excel.gif" alt="image">
</button>

<br><br>


<button type="button"  class="btn btn-success" onclick="Generar()">Generar</button>





