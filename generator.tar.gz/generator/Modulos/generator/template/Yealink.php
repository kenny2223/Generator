<?php

$suffix="cfg";


  function Create_file($data,$General,$G,$lang,$https,$pwd){
    $languages=array('Spanish' => 'es', 'English'=> 'en' , 'Portuguese' => 'po');
    
    $Idioma = array_search($lang,$languages);

  foreach ($data as $k => $v) {

if ($v[4] == "false") {
$network= <<<"n"
network.internet_port.type = 2

# Direccion IP
network.internet_port.ip = $v[5]

# Mascara de red
network.internet_port.mask = {$G["mask"]}

# gateway de red
network.internet_port.gateway = {$G["gateway"]}

# Dns1 de red
network.primary_dns = {$G["dns1"]}

# gateway de red
network.secondary_dns = {$G["dns2"]}

n;
}else $network="network.internet_port.type = 0";

if (empty($G["vlan"])) {
$vlans= <<<"v"
network.vlan.internet_port_enable = 0
network.vlan.internet_port_vid  = 0
v;
} else {
$vlans= <<<"v"
network.vlan.internet_port_enable = 1
network.vlan.internet_port_vid  = {$G["vlan"]}
v;
}

if ($pwd == "true") {
$pwds= <<<"v"
features.factory_pwd_enable = 1
v;
} else {
$pwds= <<<"v"
features.factory_pwd_enable = 0 
v;
}


$text= <<<"format"
#!version:1.0.0.1
## the file header "#!version:1.0.0.1" can not be edited or deleted. ##
#  Script Created by Ing.Mario Ruiz in VB passed to web by Ing.Kenny Ortiz
account.1.enable = 1
account.1.label = {$v[1]}
account.1.display_name = {$v[0]}
account.1.auth_name = {$v[1]}
account.1.user_name = {$v[1]}
account.1.password = {$v[2]}


#      Idioma y tonos
lang.gui = {$Idioma}
lang.wui = {$Idioma}


# Parametro Network
{$network}

# Parametro Vlan
{$vlans}

security.user_password =  admin:{$G["P_admin"]}
      
account.1.sip_server.1.address = {$G["Server"]}

#      Servidor NTP
local_time.ntp_server1 = {$G['NTP']}

#      Bloqueo de Factory Reset
{$pwds}

#  HTTPS 
wui.http_enable = 0
wui.https_enable = 1
network.port.https = {$https}



{$General}
        
format;


  file_put_contents("/tftpboot/$v[3].cfg",$text);
      
  }

}


$General= <<<"G"
##################################################
#          OTRAS CONFIGURACIONES                 #
##################################################


#      Parametros de Fecha y Hora
local_time.date_format = 1
local_time.time_zone = -6
local_time.time_zone_name = Nicaragua                                                                                                                           



#      Codec de Cuenta1
account.1.codec.pcmu.priority = 1
account.1.codec.pcma.priority = 2
account.1.codec.g729.enable = 0
account.1.codec.g729.priority = 0
account.1.codec.g722.enable = 0
account.1.codec.g722.priority = 0




G;
?>